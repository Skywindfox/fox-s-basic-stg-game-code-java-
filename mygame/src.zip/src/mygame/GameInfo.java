package mygame;

public class GameInfo 
{
	//这里什么也没有
}
