// GameUpdateCallback.java
package mygame;

public interface GameUpdateCallback {
    void update();
}
