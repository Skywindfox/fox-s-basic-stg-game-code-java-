// GameRenderCallback.java
package mygame;

public interface GameRenderCallback {
    void render();
    void setFPS(int fps); // 新增方法
}