/**
 * 
 */
/**
 * 
 */
module mygame {
	requires java.desktop;
}